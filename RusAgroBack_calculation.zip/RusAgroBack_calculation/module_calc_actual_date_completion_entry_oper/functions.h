#pragma once

// ������� ��� ���������� ����������� ��� ���������� �������� � ���������� 10%

//���������� ����������� ��� ���������� �������� �� �������
unique_pairs calc_actual_input_date_completion_entry_oper(unique_pairs uniq_pairs, initial_data init_data[])
{
    std::string field;
    int input_number;
    int days;
    std::string current_operation;

    #pragma omp parallel for private(field, input_number, days, current_operation) shared(uniq_pairs, init_data)
    for (int record_uniq = 0; record_uniq < uniq_pairs.row_count; record_uniq++)
    {
        field = uniq_pairs.higher_tm[record_uniq].value();
        for (int record_init = 0; record_init < init_data[12].row_count; record_init++)
        {
            if (!init_data[12].deadline_input[record_init].has_value())
            {
                continue;
            }
            if (uniq_pairs.material_order[record_uniq].value() == init_data[12].operation[record_init].value())
            {
                input_number = init_data[12].input_operation[record_init].value();
                days = init_data[12].deadline_input[record_init].value();
                for (int el = 0; el < init_data[12].row_count; el++)
                {
                    if (input_number == init_data[12].id[el])
                    {
                        current_operation = init_data[12].operation[el].value();
                        for (int i = 0; i < uniq_pairs.row_count; i++)
                        {
                            if (uniq_pairs.material_order[i] == current_operation and field == uniq_pairs.higher_tm[i])
                            {
                                std::tm temp = uniq_pairs.actual_data[i].value();
                                uniq_pairs.actual_input_data[record_uniq] = add_days(temp, days);
                            }
                        }
                    }
                }
            }
        }
    }
    return uniq_pairs;
}

//���������� ����������� ��� ���������� �������� �� ������������
unique_pairs calc_actual_alternative_date_completion_entry_oper(unique_pairs uniq_pairs, initial_data init_data[])
{
    std::string field;
    int alternative_number;
    int days;
    std::string current_operation;

    #pragma omp parallel for private(field, alternative_number, days, current_operation) shared(uniq_pairs, init_data)
    for (int record_uniq = 0; record_uniq < uniq_pairs.row_count; record_uniq++)
    {
        field = uniq_pairs.higher_tm[record_uniq].value();
        for (int record_init = 0; record_init < init_data[12].row_count; record_init++)
        {
            if (!init_data[12].alternative_complete[record_init].has_value())
            {
                continue;
            }
            if (uniq_pairs.material_order[record_uniq].value() == init_data[12].operation[record_init].value())
            {
                alternative_number = init_data[12].alternative_input[record_init].value();
                days = init_data[12].alternative_complete[record_init].value();
                for (int el = 0; el < init_data[12].row_count; el++)
                {
                    if (alternative_number == init_data[12].id[el])
                    {
                        current_operation = init_data[12].operation[el].value();
                        for (int i = 0; i < uniq_pairs.row_count; i++)
                        {
                            if (uniq_pairs.material_order[i] == current_operation and field == uniq_pairs.higher_tm[i])
                            {
                                std::tm temp = uniq_pairs.actual_data[i].value();
                                uniq_pairs.actual_alternative_data[record_uniq] = add_days(temp, days);
                            }
                        }
                    }
                }
            }
        }
    }
    return uniq_pairs;
}